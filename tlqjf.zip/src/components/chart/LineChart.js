const LineChart = () => {
  return <div className="feel-chart"></div>;
};

export default LineChart;
