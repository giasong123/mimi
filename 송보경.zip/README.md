<div align= "center">
    <img src="https://capsule-render.vercel.app/api?type=shark&color=000000&height=180&text=MIDE%20OF%20MINE&animation=&fontColor=fcfcfc&fontSize=70" />
    </div>
    <div align= "center"> 
    <h2 style="border-bottom: 1px solid #d8dee4; color: #282d33;"> MIMI </h2>  
    <div style="font-weight: 700; font-size: 15px; text-align: center; color: #282d33;"> 번 아웃이 온 사회인들이나 </li>감정 표현이 어려운 사람들이</li> 정신적인 피로와 스트레스에서 벗어나 </li>미래를 더 밝게 비춰드릴게요</li></li> </div> 
    </div>
    <div align= "center">
    <h2 style="border-bottom: 1px solid #d8dee4; color: #282d33;"> 🛠️ Tech Stacks </h2> <br> 
    <div style="margin: 0 auto; text-align: center;" align= "center"> <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=CSS3&logoColor=white">
          <img src="https://img.shields.io/badge/Figma-F24E1E?style=for-the-badge&logo=Figma&logoColor=white">
          <img src="https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=Git&logoColor=white">
          <img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=HTML5&logoColor=white">
          <img src="https://img.shields.io/badge/Github-181717?style=for-the-badge&logo=Github&logoColor=white">
          <br/><img src="https://img.shields.io/badge/Javascript-F7DF1E?style=for-the-badge&logo=Javascript&logoColor=white">
          <img src="https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=Node.js&logoColor=white">
          <img src="https://img.shields.io/badge/Notion-000000?style=for-the-badge&logo=Notion&logoColor=white">
          <img src="https://img.shields.io/badge/React-61DAFB?style=for-the-badge&logo=React&logoColor=white">
          <img src="https://img.shields.io/badge/Slack-4A154B?style=for-the-badge&logo=Slack&logoColor=white">
          <br/></div>
    </div>
    <div align= "center"> 
    <h2 style="border-bottom: 1px solid #d8dee4; color: #282d33;"> 🏅 Stats </h2> <div align= "center"> <img src="https://github-readme-stats.vercel.app/api?username=MIMI&custom_title=MIMI's Github Stat&bg_color=180,000000,&title_color=000000&text_color=000000"
        /> <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=MIMI&layout=compact&bg_color=180,000000,&title_color=000000&text_color=000000"
          /> </div> 
    </div>
    
