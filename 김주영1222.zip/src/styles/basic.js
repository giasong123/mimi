import styled from "@emotion/styled";
export const Wrap = styled.div`
  position: relative;
  display: flex;
  /* max-width: ${props => props.maxw + "%"}; */
  /* max-height: ${props => props.maxh + "%"}; */
`;
